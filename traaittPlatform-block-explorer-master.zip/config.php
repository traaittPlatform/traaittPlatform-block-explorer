<?php
return array(
        'api' => 'https://us-east.traaittnode.com',
        'blockTargetInterval' => 644,
        'coinUnits' => 100
);
